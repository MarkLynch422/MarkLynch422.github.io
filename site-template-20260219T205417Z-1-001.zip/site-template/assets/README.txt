Place your assets here.

Recommended:
- cv-placeholder.pdf (replace with your PDF CV)
- cv-placeholder.docx (replace with your Word CV)
- profile-photo.jpg (use in about.html)

Update about.html to point to your actual filenames.
